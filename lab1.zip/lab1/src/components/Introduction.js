import React from 'react'

function Introduction(props) {

    console.log(props)
  return (
    <div className="intro">
        <h3>{props.name}</h3>
    </div>
  )
}

export default Introduction